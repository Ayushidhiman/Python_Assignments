from collections import Counter

def remov_duplicates(input):

	# split input string separated by space
	input = input.split(" ")

	# joins two adjacent elements in iterable way
	for i in range(0, len(input)):
		input[i] = "".join(input[i])

	UniqW = Counter(input)

	s = " ".join(UniqW.keys())
	print (s)

if __name__ == "__main__":
	input = input("enter the sentence")
	remov_duplicates(input)
