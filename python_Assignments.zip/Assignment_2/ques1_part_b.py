class ReplaceThePattern:


 def replace_pattern(search_pat, replace_pat, txt):
    print(txt.replace(search_pat, replace_pat))


if __name__ == '__main__':
    txt = input("enter the text")
    search_pat = input("enter the search pattern")
    replace_pat = input("enter the replacement pattern")
    ReplaceThePattern.replace_pattern(search_pat,replace_pat,txt)