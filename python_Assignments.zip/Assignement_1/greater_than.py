def elementwise_greater_than(mylist, threshold):
    for i in mylist(1,n):
        if(mylist[i] ==threshold):
            return True
        else:
            return False

if __name__=="__main__":
    mylist =[]
    n = int(input("enter number of values:"))
    mylist = list(input("Enter the values:"))
    print(mylist)
    threshold = int(input("enter the thershold value:"))
    print(threshold)
    print(elementwise_greater_than(mylist, threshold))



