def main():
    mysentence = get_userinput()
    word_list = transform_input(mysentence)
    print_lens(build_dict_of_words(word_list))

def get_userinput():
    myinput = input("Enter a sentence:")
    return myinput

def transform_input(myinput):
    return myinput.split()

def build_dict_of_words(mylistofword):
    mydict = {}
    for word in mylistofword:
        mydict[word] = len(word)
    return mydict

def print_lens(dict_of_word):
    for key, value in dict_of_word.items():
        print(key, value)

main()