def check(a):
 count=0
 for i in a:
    count = count + 1
    print(count)
    return count
if __name__=="__main__":
 a = input("enter the string:")
 print("Length of the string is :",check(a))
