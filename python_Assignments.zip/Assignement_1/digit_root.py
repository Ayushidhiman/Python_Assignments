def digitalRoot(num):
    if (num == "0"):
        return 0
    ans=0
    for i in range(0, len(num)):
        ans = (ans + int(num[i]))

    if (len(ans)>1):
        digitalRoot(ans)
        return ans
    elif(ans==0):
        return 0
    else:
        return ans

num = "1234"
print(digitalRoot(num))