def find_longest_word():
    str= input("Please input a list of words: ")

    longest = 0

    for words in str.split():
        if len(words) > longest:
            longest = len(words)
            longest_word = words

    print("The longest word is", longest_word, "with length", len(longest_word))

find_longest_word()