def add(myList):
    result = 0
    for i in myList:
        result = result + i
    return result

def multiply(myList):
    result = 1
    for x in myList:
        result = result * x
    return result

mylist=[1,2,3,4]
print(add(mylist))
print(multiply(mylist))