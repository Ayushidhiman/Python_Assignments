class perfect:
    Num = int(input("Enter a number:"))
    sum=0
    for i in range(1,Num):
        if(Num % i==0):
         sum = sum + i
    if(sum==Num):
        print("%d is a prefect number" %Num)
    else:
        print("%d is not a prefect number" %Num)

