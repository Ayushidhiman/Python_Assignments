def check(word):
        word = word.lower()
        len = len(word)
        if(len>0):
          new= set(word)
        elif(len== new):
            print("word is isogram")
        else:
            print("word is not isogram")
if __name__=='__main__':
    word =input("enter a word")
    check(word)

