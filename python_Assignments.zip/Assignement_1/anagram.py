def anagram():
    l=len(mylist)
    for s in mylist(s,l):
        if mylist[s]==str:
            print(mylist[s])
        else:
            print("words is not in mylist")

mylist=["ant","car","ball","toy"]
str ="ccc"
