def is_member(x,a):
    i = 0
    while i < len(a):
        if (x == a[i]):
            return True
            i = i + 1
        else:
            i = i + 1
    return False
a=input("enter the value in list:")
x=input("value to be search:")
print (is_member(x,a))
