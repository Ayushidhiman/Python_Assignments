def unique_words(mylist):
    mydict = {}
    for c in mylist.split():
        if c in mydict:
            mydict[c] += 1
        else:
            mydict[c] = 1
    return mydict

mylist=input("enter the string:")
print(unique_words(mylist))