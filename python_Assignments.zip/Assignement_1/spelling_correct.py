import re
def correct(String):
    corrected_String = re.sub('\ +', ' ', String)
    corrected_String = re.sub('\.', '. ', corrected_String)

    print(corrected_String)


String=input("Enter the string:")
correct(String)
