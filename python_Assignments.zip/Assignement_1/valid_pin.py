def is_valid_pin(pin_code):
    l=len(pin_code)
    if(l==6):
       print("Its a valid pin code")
       return True
    else:
      print("Its not a valid pin code")
      return False

pin_code=input("Enter pincode:")
print(is_valid_pin(pin_code))