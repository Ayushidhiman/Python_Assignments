class max:
 a = 25
 b = 12
 if a > b:
    print("a is a greater no.")
 elif b > a :
    print (" b is greater no.")
 else:
    print("both are equal")
