def palindrome(s):
    str = ""
    for i in s:
        str = i + str
    if(str==s):
        return True
    else:
        return False

s = input("enter the string:")
print("Is string is palindrome:",palindrome(s))