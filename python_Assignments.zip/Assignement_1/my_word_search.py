def my_word_search(my_doc_list, my_keyword):
     for c in my_doc_list.split():
         if my_keyword in my_doc_list:
             return my_doc_list.index(my_keyword)
         else:
             print("keyword not found")


my_doc_list=input("enter the values in the document:")
my_keyword=input("enter the word to be searched:")
value=my_word_search(my_doc_list,my_keyword)
print(my_keyword ,"is at the ",value, "location in the document")
