def char_freq(str):
    mydict = {}
    for c in str:
        if c in mydict:
            mydict[c] += 1
        else:
            mydict[c] = 1
    return mydict

str=input("enter the string:")
print(char_freq(str))