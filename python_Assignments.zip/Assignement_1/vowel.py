def Vowel(char):
    if(char == 'a' or char=='e' or char=='i' or char== 'o' or char== 'u' or char== 'A' or char== 'E' or char== 'I' or char== 'O' or char== 'U'):
        return True
    else:
        return False

if __name__=="__main__":
    char = input("enter the characterj value:")
    print(Vowel(char))
