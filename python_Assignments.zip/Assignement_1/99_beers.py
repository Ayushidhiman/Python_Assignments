c=99
while(c > 0):
    print(c,"bottom of beer on the wall, ",c,"bottles of beer")
    c=c-1
    print("Take on down, pass it around, ",c,"bottles of beer on the wall")
