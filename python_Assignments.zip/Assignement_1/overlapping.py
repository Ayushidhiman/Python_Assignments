def overlapping(x,a):
    i = 0
    while i < len(a):
        if (x[i]== a[i]):
            return True
            i = i + 1
        else:
            i = i + 1
    return False
a=input("enter the value in list 1:")
x=input("enter the values in list 2:")
print (overlapping(x,a))
