import re
def Fetch_email_address():
 str = 'You will parse the From line and ayushidhiman9@gmail.comlines and print out a ayushidhiman39@gamil.com count at the end'

 emailID = re.findall('\S+@\S+', str)

 print(emailID)
Fetch_email_address()
